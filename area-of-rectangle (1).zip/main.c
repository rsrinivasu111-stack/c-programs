#include<stdio.h>
int main()
{
 int l,b,area;
 printf("enter l,b values");
 scanf("%d%d",&l,&b);
 area=l*b;
 printf("area=%d",area);
 return 0;
}