#include<stdio.h>
int main()
{
    int s,area;
    printf("enter s value");
    scanf("%d",&s);
    area=s*s;
    printf("area=%d",area);
    return 0;
}